package org.tnsif.operator;

public class BitwiseOperator {

	public static void main(String[] args) {
		int x= 13;
		int y = 9;
		int a =8;
		int b = 1;
		
		System.out.println(x & y);
		System.out.println(x | y);
		System.out.println(x ^ y);
		System.out.println(a << b);
		System.out.println(a >> b);

	}

}
