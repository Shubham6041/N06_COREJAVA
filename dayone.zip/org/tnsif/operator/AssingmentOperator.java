package org.tnsif.operator;

public class AssingmentOperator {

	public static void main(String[] args) {
		int x= 15, y=5;
		x-=y;
		System.out.println(x);

	}

}
