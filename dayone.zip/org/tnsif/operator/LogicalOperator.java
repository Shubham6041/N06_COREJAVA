package org.tnsif.operator;

public class LogicalOperator {

	public static void main(String[] args) {
		System.out.println(30!=7 && 3>=5);
		System.out.println(31!=7 || 3>5);
		System.out.println(!(31!=7 || 3>5));

	}

}
