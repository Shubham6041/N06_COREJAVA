// program to demonstrate on compile-time-input

package org.tnsif.introduction;

public class CompilerInput {

	public static void main(String[] args) {
		short num = 31;
		System.out.println("The number is: "+num);

	}

}
